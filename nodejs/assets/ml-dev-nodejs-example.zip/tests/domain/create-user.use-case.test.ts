import { CreateUserDto } from "../../src/domain/dtos";
import { UserEntity } from "../../src/domain/entities";
import { UserRepository } from "../../src/domain/repositories";
import { CreateUserUseCase } from "../../src/domain/use-cases/user";

describe("CreateUserUseCase", () => {
  let mockRepo: jest.Mocked<UserRepository>;
  let useCase: CreateUserUseCase;

  beforeEach(() => {
    mockRepo = {
      createUser: jest.fn(),
      getUsers: jest.fn(),
    };

    useCase = new CreateUserUseCase(mockRepo);
  });

  it("✅ debería crear un usuario correctamente", async () => {
    // Arrange
    const dto: CreateUserDto = { name: "Alice", email: "alice@example.com" };
    const expectedUser = new UserEntity(1, dto.name, dto.email);

    mockRepo.createUser.mockResolvedValueOnce(expectedUser);

    // Act
    const result = await useCase.execute(dto);

    // Assert
    expect(mockRepo.createUser).toHaveBeenCalledTimes(1);
    expect(mockRepo.createUser).toHaveBeenCalledWith(dto);
    expect(result).toBeInstanceOf(UserEntity);
    expect(result).toEqual(expectedUser);
  });

  it("❌ debería propagar un error si el repositorio falla", async () => {
    // Arrange
    const dto: CreateUserDto = { name: "Bob", email: "bob@example.com" };
    const repoError = new Error("Database down");

    mockRepo.createUser.mockRejectedValueOnce(repoError);

    // Act & Assert
    await expect(useCase.execute(dto)).rejects.toThrow("Database down");
    expect(mockRepo.createUser).toHaveBeenCalledWith(dto);
  });
});
