import express from "express";
import request from "supertest";
import router from "../../src/presentation/routes";

// 1) MOCK DEL REPO *ANTES* DE IMPORTAR EL ROUTER
jest.mock("../../src/infrastructure/repositories", () => {
  // constructor mock que expone métodos mockeados
  const Impl = jest.fn().mockImplementation(() => ({
    getUsers: jest.fn().mockResolvedValue([]),
    createUser: jest.fn().mockImplementation(async (dto) => ({
      // devuelve objeto plano JSON-serializable
      id: 1,
      name: dto.name,
      email: dto.email,
    })),
  }));
  return { UserRepositoryImpl: Impl };
});

describe("User Router", () => {
  let app: express.Express;
  let router: express.Router;

  beforeEach(async () => {
    jest.resetModules(); // limpia cache de módulos
    app = express();
    app.use(express.json());

    // 2) IMPORTA EL ROUTER *DESPUÉS* DEL MOCK
    // Ajusta la ruta según tu estructura real:
    // si tu router está en src/presentation/routes/index.ts:
    ({ default: router } = await import("../../src/presentation/routes"));
    // si está en src/presentation/routes.ts, usa:
    // ({ default: router } = await import("../../src/presentation/routes"));

    // 3) MONTA CON EL MISMO PREFIJO QUE server.ts
    app.use("/api", router);
  });

  it("GET /api/users → 200 []", async () => {
    const res = await request(app).get("/api/users");
    expect(res.status).toBe(200);
    expect(res.headers["content-type"]).toMatch(/application\/json/);
    expect(res.body).toEqual([]); // viene del mock
  });

  it("POST /api/users → 201 crea", async () => {
    const dto = { name: "Bob", email: "bob@example.com" };
    const res = await request(app).post("/api/users").send(dto);

    // Diagnóstico útil si algo vuelve a romper
    if (res.status !== 201 || typeof res.body !== "object") {
      // eslint-disable-next-line no-console
      console.error("DEBUG:", {
        status: res.status,
        ct: res.headers["content-type"],
        text: res.text,
      });
    }

    expect(res.status).toBe(201);
    expect(res.headers["content-type"]).toMatch(/application\/json/);
    expect(res.body).toMatchObject({ id: expect.any(Number), ...dto });
  });
});
