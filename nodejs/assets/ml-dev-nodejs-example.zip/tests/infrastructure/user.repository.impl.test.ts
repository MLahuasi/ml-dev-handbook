import { CreateUserDto } from "../../src/domain/dtos";
import { UserEntity } from "../../src/domain/entities";
import { UserJsonDatasource } from "../../src/infrastructure/datasources/json/users.datasource";
import { UserRepositoryImpl } from "../../src/infrastructure/repositories";

// Mockeamos la clase UserJsonDatasource completa
jest.mock("../../src/infrastructure/datasources/json/users.datasource", () => {
  return {
    UserJsonDatasource: {
      load: jest.fn(),
      save: jest.fn(),
    },
  };
});

describe("UserRepositoryImpl", () => {
  let repo: UserRepositoryImpl;

  beforeEach(() => {
    jest.clearAllMocks();
    repo = new UserRepositoryImpl();
  });

  describe("createUser", () => {
    it("✅ debería crear un usuario con id incremental y guardarlo", async () => {
      // Arrange
      const existingUsers = [
        { id: 1, name: "Alice", email: "alice@example.com" },
        { id: 2, name: "Bob", email: "bob@example.com" },
      ];
      (UserJsonDatasource.load as jest.Mock).mockResolvedValueOnce(
        existingUsers
      );
      (UserJsonDatasource.save as jest.Mock).mockResolvedValueOnce(undefined);

      const dto: CreateUserDto = {
        name: "Charlie",
        email: "charlie@example.com",
      };

      // Act
      const result = await repo.createUser(dto);

      // Assert
      expect(UserJsonDatasource.load).toHaveBeenCalledTimes(1);
      expect(UserJsonDatasource.save).toHaveBeenCalledTimes(1);

      const savedUsers = (UserJsonDatasource.save as jest.Mock).mock
        .calls[0][0];
      expect(savedUsers).toHaveLength(3);
      expect(savedUsers[2]).toMatchObject({ id: 3, ...dto });

      expect(result).toBeInstanceOf(UserEntity);
      expect(result).toEqual(new UserEntity(3, dto.name, dto.email));
    });

    it("✅ debería asignar id=1 si no hay usuarios previos", async () => {
      (UserJsonDatasource.load as jest.Mock).mockResolvedValueOnce([]);
      (UserJsonDatasource.save as jest.Mock).mockResolvedValueOnce(undefined);

      const dto: CreateUserDto = { name: "Dani", email: "dani@example.com" };
      const result = await repo.createUser(dto);

      expect(result.id).toBe(1);
      expect(result.name).toBe("Dani");
    });
  });

  describe("getUsers", () => {
    it("✅ debería mapear correctamente los raw users a entidades", async () => {
      const raw = [
        { id: 1, name: "Alice", email: "alice@example.com" },
        { id: 2, name: "Bob", email: "bob@example.com" },
      ];
      (UserJsonDatasource.load as jest.Mock).mockResolvedValueOnce(raw);

      const result = await repo.getUsers();

      expect(UserJsonDatasource.load).toHaveBeenCalledTimes(1);
      expect(result).toHaveLength(2);
      expect(result[0]).toBeInstanceOf(UserEntity);
      expect(result[0]).toEqual(
        new UserEntity(1, "Alice", "alice@example.com")
      );
      expect(result[1]).toEqual(new UserEntity(2, "Bob", "bob@example.com"));
    });
  });
});
