// src/presentation/user/controller.ts
import type { Request, Response } from "express";
import { UserRepository } from "../../domain/repositories";
import { CreateUserUseCase } from "../../domain/use-cases/user";

export class UserController {
  constructor(private readonly userRepo: UserRepository) {}

  create = async (req: Request, res: Response) => {
    try {
      const useCase = new CreateUserUseCase(this.userRepo);
      const user = await useCase.execute(req.body);
      res.status(201).json(user);
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  };

  list = async (_req: Request, res: Response) => {
    try {
      const users = await this.userRepo.getUsers();
      res.json(users);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  };
}
