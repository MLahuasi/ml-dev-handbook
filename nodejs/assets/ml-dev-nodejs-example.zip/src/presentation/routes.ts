import { Router } from "express";
import { UserRepositoryImpl } from "../infrastructure/repositories";
import { UserController } from "./user";

const router = Router();
const repo = new UserRepositoryImpl();
const controller = new UserController(repo);

router.get("/users", controller.list);
router.post("/users", controller.create);

export default router;
