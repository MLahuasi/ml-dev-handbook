// src/presentation/server.ts
import express from "express";
import router from "./routes";

export function createServer() {
  const app = express();
  app.use(express.json()); // <-- necesario para POST JSON

  app.use("/api", router);

  app.get("/health", (_req, res) => res.json({ ok: true }));

  return app;
}
