// src/config/plugins/envs.plugin.ts
import "dotenv/config";
import env from "env-var"; // <- default import

export const envs = {
  HOST: env.get("HOST").default("127.0.0.1").asString(),
  PORT: env.get("PORT").default("3000").asPortNumber(),
  NODE_ENV: env.get("NODE_ENV").default("development").asString(),
};
