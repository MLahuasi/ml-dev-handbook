// src/infrastructure/repositories/user.repository.impl.ts

import { CreateUserDto } from "../../domain/dtos";
import { UserEntity } from "../../domain/entities";
import { UserRepository } from "../../domain/repositories";
import { UserJsonDatasource } from "../datasources/json/users.datasource";

export class UserRepositoryImpl implements UserRepository {
  async createUser(dto: CreateUserDto): Promise<UserEntity> {
    const users = await UserJsonDatasource.load();
    const nextId = (users.reduce((m, u) => Math.max(m, u.id), 0) || 0) + 1;

    const raw = { id: nextId, name: dto.name, email: dto.email };
    users.push(raw);
    await UserJsonDatasource.save(users);

    return new UserEntity(raw.id, raw.name, raw.email);
  }

  async getUsers(): Promise<UserEntity[]> {
    const users = await UserJsonDatasource.load();
    return users.map((u) => new UserEntity(u.id, u.name, u.email));
  }
}
