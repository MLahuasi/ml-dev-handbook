// src/infrastructure/datasources/json/users.datasource.ts
import { promises as fs } from "node:fs";
import path from "node:path";

export type RawUser = { id: number; name: string; email: string };

// En CJS __dirname existe
const JSON_FILE = path.resolve(__dirname, "users.json");

export class UserJsonDatasource {
  static async load(): Promise<RawUser[]> {
    const content = await fs.readFile(JSON_FILE, "utf8");
    return JSON.parse(content) as RawUser[];
  }
  static async save(users: RawUser[]): Promise<void> {
    await fs.writeFile(JSON_FILE, JSON.stringify(users, null, 2), "utf8");
  }
}
