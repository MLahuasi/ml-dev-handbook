// src/domain/entities/user.entity.ts
export class UserEntity {
  constructor(
    public readonly id: number,
    public name: string,
    public email: string
  ) {}
}
