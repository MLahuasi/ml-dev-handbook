export interface CreateUserDto {
  name: string;
  email: string;
}
