// src/domain/use-cases/user/create-user.use-case.ts

import { CreateUserDto } from "../../dtos";
import { UserEntity } from "../../entities";
import { UserRepository } from "../../repositories";

export class CreateUserUseCase {
  constructor(private readonly userRepo: UserRepository) {}

  async execute(dto: CreateUserDto): Promise<UserEntity> {
    // Aquí puedes aplicar lógica de negocio (ej: validar duplicados)
    return this.userRepo.createUser(dto);
  }
}
