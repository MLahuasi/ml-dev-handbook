// src/domain/repositories/user.repository.ts

import { CreateUserDto } from "../dtos";
import { UserEntity } from "../entities";

export interface UserRepository {
  createUser(dto: CreateUserDto): Promise<UserEntity>;
  getUsers(): Promise<UserEntity[]>;
}
