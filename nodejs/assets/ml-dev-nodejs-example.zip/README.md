# REST Web Server – Node.js (Arquitectura Limpia)

Servicio mínimo para **crear usuarios** y **listar usuarios**. Incluye una ruta de **salud**.

## Requisitos

- Node.js 18+ (LTS recomendado)
- npm (o pnpm/yarn si prefieres)

---

## Instalación

```bash
npm install
```

## Configuración

> - Para configurar las variables de entorno de la aplicación se debe crear el archivo `.env` basado en la estructura de [`.env.template`](./.env.template) (no es buena prática publicar el archivo `.env` en GitHub)

## Iniciar el servidor

### Desarrollo (recarga en caliente)

```bash
npm run dev
```

Servidor en: http://127.0.0.1:3000

### Producción (compilar y ejecutar)

```bash
npm run build
npm start
```

### Test

```bash
npm test
```

## Endpoints

### 1) Healthcheck

> - **GET** `http://127.0.0.1:3000/health`

Respuesta ejemplo:

```json
{ "ok": true }
```

### 2) Crear usuario

> - **POST** `http://127.0.0.1:3000/api/users`
> - Body (JSON)

```json
{
  "name": "Bob D",
  "email": "bobyd@mail.com"
}
```

> - Respuesta ejemplo:

```json
{
  "id": 3,
  "name": "Bob D",
  "email": "bobyd@mail.com"
}
```

> - Ejemplo con curl:

```bash
curl -X POST "http://127.0.0.1:3000/api/users" \
  -H "Content-Type: application/json" \
  -d '{"name":"Bob D","email":"bobyd@mail.com"}'
```

### 3) Listar usuarios

> - **GET** `http://127.0.0.1:3000/api/users`
> - Respuesta ejemplo:

```json
[
  {
    "id": 1,
    "name": "Alice Doe",
    "email": "alice@example.com"
  },
  {
    "id": 2,
    "name": "Bob Roe",
    "email": "bob@example.com"
  },
  {
    "id": 3,
    "name": "Bob D",
    "email": "bobyd@mail.com"
  }
]
```
