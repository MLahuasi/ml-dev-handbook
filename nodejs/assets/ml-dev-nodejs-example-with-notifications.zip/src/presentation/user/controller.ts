// src/presentation/user/controller.ts
import type { NextFunction, Request, Response } from "express";
import { UserRepository } from "../../domain/repositories";
import { CreateUserUseCase } from "../../domain/use-cases/user";
import { notify } from "../../infrastructure/notifications/notify";
import { MailAddress } from "@jmlq/mailer";
import { toCsv } from "../../shared/helpers";
import { renderTable } from "../../infrastructure/notifications/helpers";

export class UserController {
  constructor(private readonly userRepo: UserRepository) {}

  create = async (req: Request, res: Response, next: NextFunction) => {
    try {
      // Usa el logger con contexto
      req.logger?.info("user.create.start", {
        requestId: req.requestId,
        body: req.body,
      });
      const useCase = new CreateUserUseCase(this.userRepo);
      const user = await useCase.execute(req.body);

      req.logger?.info("user.create.success", {
        requestId: req.requestId,
        userId: user.id,
      });
      res.status(201).json(user);
    } catch (err: any) {
      return next(err);
    }
  };

  list = async (req: Request, res: Response, next: NextFunction) => {
    try {
      req.logger?.info("user.list.start", { requestId: req.requestId });

      const users = await this.userRepo.getUsers();

      // ---- Envío de correo con el listado ----
      // 1) Definir destinatario(s)
      const to: MailAddress[] = [
        {
          email: "jmlahuasiq@hotmail.com",
          name: "MLahuasi",
        },
        {
          email: "maurojre@hotmail.com",
          name: "MLahuasi",
        },
      ];

      // 2) Armar contenido
      const rows = users.map((u) => ({
        ID: u.id,
        Name: (u as any).name ?? "",
        Email: (u as any).email ?? "",
      }));

      const html =
        typeof renderTable === "function"
          ? renderTable({
              title: "Listado de Usuarios",
              subtitle: `Total: ${users.length}`,
              rows, // [{ID, Name, Email}]
            })
          : // Fallback simple si no tienes renderTable exportado:
            `<h2>Listado de Usuarios</h2>
             <p>Total: ${users.length}</p>
             <table border="1" cellspacing="0" cellpadding="6">
               <thead><tr><th>ID</th><th>Name</th><th>Email</th></tr></thead>
               <tbody>
                 ${rows
                   .map(
                     (r) =>
                       `<tr><td>${r.ID}</td><td>${r.Name}</td><td>${r.Email}</td></tr>`
                   )
                   .join("")}
               </tbody>
             </table>`;

      const subject = `Reporte: ${users.length} usuarios encontrados`;

      // Generar adjunto CSV
      const csv = toCsv(rows);
      const fileName = `users_${new Date()
        .toISOString()
        .replace(/[:.]/g, "-")}.csv`;

      // 3) Disparar el correo SIN bloquear la respuesta
      //    (loggea si falla, pero no rompas la petición)
      notify({
        to,
        subject,
        html,
        text: `Total: ${users.length} usuarios`,
        attachments: [
          {
            filename: fileName,
            content: Buffer.from(csv, "utf-8"), // también puede ser string, según tu adapter
            contentType: "text/csv",
          },
        ],
      }).catch((e) => {
        req.logger?.warn("user.list.email_failed", {
          error: (e as Error).message,
          requestId: req.requestId,
        });
      });
      // ---- fin envío de correo ----

      req.logger?.info("user.list.success", {
        count: users.length,
        requestId: req.requestId,
      });

      res.json(users);
    } catch (err: any) {
      return next(err);
    }
  };
}
