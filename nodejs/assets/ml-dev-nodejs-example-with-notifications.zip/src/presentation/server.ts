// src/presentation/server.ts
import express, { Request, Response, NextFunction } from "express";
import router from "./routes";
// Errors and Logs

import { randomUUID } from "node:crypto";
import type { ILogger } from "@jmlq/logger";
import { errorHandler } from "./middlewares/http/error.middleware";

// --- Middleware para adjuntar logger por request (con contexto útil) ---
function attachLogger(base: ILogger) {
  return async (req: Request, _res: Response, next: NextFunction) => {
    req.logger = base;
    req.requestId = (req.headers["x-request-id"] as string) ?? randomUUID();
    next();
  };
}

export function createServer(base: ILogger) {
  const app = express();
  app.use(express.json()); // <-- necesario para POST JSON
  app.use(attachLogger(base));

  app.use("/api", router);

  app.get("/health", (_req, res) => res.json({ ok: true }));

  // IMPORTANTE: Siempre errorHandler se coloca al último
  app.use(errorHandler());

  return app;
}
