// Centraliza la conversión AppError → HTTP status + respuesta.
// Además, envuelve los errores desconocidos en AppError.internal(...)
// para que el hook del bridge también los loguee.

// src/presentation/http/error.middleware.ts
import { NextFunction, Request, Response } from "express";
import { AppError, isAppError } from "../../../shared/errors";
import { notifyCriticalError } from "../../../infrastructure/notifications";
import { getLogLevelForAppError } from "../../../shared/errors";

// Mapeo recomendado: AppErrorCode -> HTTP status
export function getHttpStatusForAppError(code: AppError["code"]): number {
  switch (code) {
    case "VALIDATION":
      return 400;
    case "NOT_FOUND":
      return 404;
    case "CONFLICT":
      return 409;
    case "INVARIANT":
      return 422; // o 500 si prefieres
    case "INTERNAL":
    default:
      return 500;
  }
}

/**
 * Middleware de manejo de errores central.
 * - Si no es AppError, lo envuelve en AppError.internal (dispara hook y log).
 * - Devuelve un JSON estable (problem-like) sin PII.
 */
export function errorHandler() {
  return (err: unknown, req: Request, res: Response, _next: NextFunction) => {
    let appErr: AppError;

    if (!isAppError(err)) {
      // Envuelve en INTERNAL; tu código ya lo hace en general.
      appErr = AppError.internal("Unhandled exception", { cause: err });
    } else {
      appErr = err as AppError;
    }

    // Si es INTERNAL (o lo que mapee a ERROR), notifica con contexto HTTP
    const status = getHttpStatusForAppError(appErr.code);

    // Calcula el nivel a partir del AppErrorCode y deja que el notifier aplique la política
    const level = getLogLevelForAppError(appErr.code);

    notifyCriticalError(level, "http.error", appErr, {
      requestId: req.requestId,
      method: req.method,
      route: req.originalUrl,
      ip: req.ip,
      userAgent: req.headers["user-agent"] as string,
      extra: { query: req.query }, // evita body si puede tener PII
    }).catch(() => console.log(`Internal Error: notifyCriticalError`));

    const body = {
      error: {
        code: appErr.code,
        message: appErr.message,
        retryable: appErr.retryable,
        // meta: appErr.meta, // incluir sólo si no se usa PII
      },
    };

    res.status(status).json(body);
  };
}
