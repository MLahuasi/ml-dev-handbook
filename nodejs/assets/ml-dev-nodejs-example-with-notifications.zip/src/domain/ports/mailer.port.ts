// src/domain/ports/mailer.port.ts
export type MailAddress = { name?: string; email: string };

export type SendEmailAttachment = {
  filename: string;
  path?: string;
  content?: string | Buffer;
  contentType?: string; // opcional
};

export type SendEmailOptions = {
  to: MailAddress | MailAddress[];
  subject: string;
  html: string;
  text: string;
  cc?: MailAddress | MailAddress[];
  bcc?: MailAddress | MailAddress[];
  attachments?: SendEmailAttachment[];
};

export interface MailerPort {
  send(options: SendEmailOptions): Promise<{ messageId: string }>;
}
