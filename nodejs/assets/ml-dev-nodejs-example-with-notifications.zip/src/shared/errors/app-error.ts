// Define un tipo de código con categorías comunes
export type AppErrorCode =
  | "VALIDATION"
  | "NOT_FOUND"
  | "CONFLICT"
  | "INVARIANT"
  | "INTERNAL";

// Expone opciones para adjuntar cause (error original), meta (datos extra) y retryable.
export interface AppErrorOptions {
  code: AppErrorCode;
  cause?: unknown; // Error original (si aplica)
  meta?: Record<string, unknown>; // Datos útiles (sin PII)
  retryable?: boolean; // ¿Tiene sentido reintentar?
}

/**
 * Callback global (hook) que se ejecuta automáticamente
 * cada vez que se crea un AppError. Permite enganchar logging/metricas
 * sin repetir código en cada throw o catch.
 */
export type AppErrorHook = (err: AppError) => void;

export class AppError extends Error {
  // Se llama “hook” porque actúa como un punto de enganche para lógica externa.
  // Es un lugar donde se puede “colgar” una función que reaccione a un evento.
  // En este caso, el evento es: “se creó un AppError”
  static hook?: AppErrorHook;

  // Informacionn del error
  readonly code: AppErrorCode;
  readonly meta?: Record<string, unknown>;
  readonly retryable: boolean;

  constructor(message: string, opts: AppErrorOptions) {
    // Crear Error, similar a: throw new Error("No se pudo procesar la respuesta", { cause: e });
    super(message, { cause: opts.cause as any }); // Node 16+/TS 4.6+
    // Establecer valores del error
    this.name = "AppError";
    this.code = opts.code;
    this.meta = opts.meta;
    this.retryable = opts.retryable ?? false;

    // Normaliza el prototipo y captura stack-trace si está disponible.
    // Donde:
    // new.target es una referencia a la clase concreta que invocó el constructor (AppError).
    // new.target.prototype es el prototype real de esa clase.
    // Object.setPrototypeOf(this, ...) fuerza a que la instancia (this) apunte al prototipo correcto.
    // IMPORTANTE: Asegura que el error custom se comporte como instancia de la clase.
    Object.setPrototypeOf(this, new.target.prototype);

    // En navegadores y Node.js modernos, un Error incluye una stack trace (el listado de funciones que llevaron al error). Pero su captura puede ser inconsistente.
    // Donde:
    // Error.captureStackTrace es una función propia de V8 (el motor de Node.js/Chrome).
    // IMPORTANTE: Mejora la legibilidad de la traza. captura una stack trace clara y útil para debugging/logging.
    if (Error.captureStackTrace) Error.captureStackTrace(this, AppError);

    // Dispara el hook si está configurado
    // Dentro del constructor de AppError, this hace referencia a la instancia recién creada de AppError.
    // Es decir, el objeto completo del error que acabas de construir con todas sus propiedades (message, code, meta, retryable, stack, etc.).
    // Ejemplo: const err = new AppError("Usuario no encontrado", { code: "NOT_FOUND" });
    //          this apunta a err.
    AppError.hook?.(this);
  }

  // Dispara el hook si está configurado
  static setHook(h: AppErrorHook) {
    AppError.hook = h;
  }
  static clearHook() {
    AppError.hook = undefined;
  }

  // Expone helpers estáticos para crear errores tipificados
  static validation(message: string, meta?: Record<string, unknown>) {
    return new AppError(message, {
      code: "VALIDATION",
      meta,
      retryable: false,
    });
  }
  static notFound(message: string, meta?: Record<string, unknown>) {
    return new AppError(message, { code: "NOT_FOUND", meta, retryable: false });
  }
  static conflict(message: string, meta?: Record<string, unknown>) {
    return new AppError(message, { code: "CONFLICT", meta, retryable: false });
  }
  static invariant(message: string, meta?: Record<string, unknown>) {
    return new AppError(message, { code: "INVARIANT", meta, retryable: false });
  }
  static internal(message = "Internal Error", cause?: unknown) {
    return new AppError(message, { code: "INTERNAL", cause, retryable: false });
  }

  // Serializa el error en un payload seguro para logging (reduce el cause a {name,message} si es Error).
  toLog() {
    const cause = (this as any).cause;
    const safeCause =
      cause instanceof Error
        ? { name: cause.name, message: cause.message }
        : cause;

    return {
      name: this.name,
      code: this.code,
      message: this.message,
      retryable: this.retryable,
      meta: this.meta,
      cause: safeCause,
      stack: this.stack,
    };
  }

  // Sobrescribe toJSON() para que el error sea serializable (útil en respuestas y logs).
  toJSON() {
    return this.toLog();
  }
}

// Provee un type guard
export function isAppError(err: unknown): err is AppError {
  return err instanceof AppError;
}
