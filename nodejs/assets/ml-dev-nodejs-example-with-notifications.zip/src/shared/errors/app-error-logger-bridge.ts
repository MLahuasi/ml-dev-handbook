// src/shared/errors/app-error-logger-bridge.ts
import { loggerReady } from "../../config/logger";
import { notifyCriticalError } from "../../infrastructure/notifications";
import { AppError, AppErrorCode } from "./app-error";
import { LogLevel } from "@jmlq/logger"; // asumiendo enum o tipos del core

/** Mapeo central: AppErrorCode -> LogLevel */
export function getLogLevelForAppError(code: AppErrorCode): LogLevel {
  switch (code) {
    case "VALIDATION":
      return LogLevel.WARN;
    case "NOT_FOUND":
      return LogLevel.INFO;
    case "CONFLICT":
      return LogLevel.WARN;
    case "INTERNAL":
      return LogLevel.ERROR;
    case "INVARIANT":
      return LogLevel.ERROR;
    default:
      return LogLevel.ERROR;
  }
}

/** Log seguro: usa logger si está listo; si no, console.error */
async function safeLogError(msg: string, meta?: unknown) {
  try {
    (await loggerReady).error(msg, meta);
  } catch {
    console.error(msg, meta);
  }
}

/**
 * Inicializa el hook de AppError una sola vez.
 * Nota: side-effect al importarlo (bootstrap implícito).
 */
let initialized = false;

async function init() {
  if (initialized) return;
  initialized = true;

  const logger = await loggerReady; // Reutiliza tu inicialización existente

  AppError.setHook((err) => {
    const lvl = getLogLevelForAppError(err.code);
    const eventName = "app.error"; // evento estructurado
    const payload = err.toLog();

    // Notificación por email solo para niveles ERROR
    if (lvl === LogLevel.ERROR) {
      // Bridge agnóstico a HTTP; solo manda extra con cuidado de PII
      notifyCriticalError(LogLevel.ERROR, eventName, err, {
        extra: payload, // asegúrate de que no incluya PII sensible
      }).catch(() => {
        // Si falló el envío de alerta, registra el fallo sin romper el flujo
        void safeLogError("[notifyCriticalError] send failed (bridge)", {
          errMessage: (err as any)?.message,
        });
      });
    }

    // Enrutamiento por nivel (usa el método del logger correcto)
    switch (lvl) {
      case LogLevel.INFO:
        logger.info(eventName, payload);
        break;
      case LogLevel.WARN:
        logger.warn(eventName, payload);
        break;
      case LogLevel.ERROR:
      default:
        logger.error(eventName, payload);
        break;
    }
  });
}

// Arranca en cuanto se importa el módulo.
init().catch((e) => {
  void safeLogError("[AppErrorBridge] init failed:", {
    message: e?.message,
    stack: e?.stack,
  });
});
