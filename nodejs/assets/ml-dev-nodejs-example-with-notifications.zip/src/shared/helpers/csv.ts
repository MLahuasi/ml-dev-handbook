/**
 * Util simple para convertir a CSV (encabezado + filas).
 * Mantiene la misma lógica que tu función original.
 */
export function toCsv<T extends Record<string, any>>(data: T[]): string {
  if (!data.length) return "id,name,email\n"; // cabecera básica si no hay datos
  const headers = Object.keys(data[0]);
  const escape = (val: unknown) => {
    if (val === null || val === undefined) return "";
    const s = String(val);
    // Si contiene comillas, coma o salto de línea → encierra en comillas y duplica comillas internas
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const headerLine = headers.join(",");
  const lines = data.map((row) => headers.map((h) => escape(row[h])).join(","));
  return [headerLine, ...lines].join("\n");
}
