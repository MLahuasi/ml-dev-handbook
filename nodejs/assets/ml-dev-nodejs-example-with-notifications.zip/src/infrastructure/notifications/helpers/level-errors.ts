import { LogLevel } from "@jmlq/logger";

/** Mapea string a LogLevel */
export function toErrorLogLevel(s: string): LogLevel {
  const x = (s ?? "").trim().toUpperCase();
  switch (x) {
    case "INFO":
      return LogLevel.INFO;
    case "WARN":
    case "WARNING":
      return LogLevel.WARN;
    case "ERROR":
    default:
      return LogLevel.ERROR;
  }
}

// Comparación consistente (por si el enum no es 0/1/2)
export function levelErrorRank(l: LogLevel): number {
  switch (l) {
    case LogLevel.INFO:
      return 1;
    case LogLevel.WARN:
      return 2;
    case LogLevel.ERROR:
    default:
      return 3;
  }
}
