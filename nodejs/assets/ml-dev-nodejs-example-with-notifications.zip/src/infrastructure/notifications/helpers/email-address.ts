/** Direcciones de correo (mismo shape que tenías en notify.ts) */
export type Address = string | { email: string; name?: string };
export type Addresses = Address | Address[];

/** Normaliza Address|Address[] a {email,name?}[] */
export function toRecipients(
  addr: Addresses
): { email: string; name?: string }[] {
  const arr = Array.isArray(addr) ? addr : [addr];
  return arr.map((a) => (typeof a === "string" ? { email: a } : a));
}
