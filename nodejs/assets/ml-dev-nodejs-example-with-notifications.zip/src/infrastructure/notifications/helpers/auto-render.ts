import { escapeHtml, renderKV, renderTable, renderJSON } from "./html";
import type { NotifyAttachment } from "./attachments";
import { Addresses } from ".";

export type NotifyOptions = {
  subject: string;
  html?: string;
  text?: string;

  title?: string;
  context?: Record<string, unknown>;
  data?: unknown;
  maxRows?: number;
  truncate?: number;

  to: Addresses;
  cc?: Addresses;
  bcc?: Addresses;

  attachments?: NotifyAttachment[];
};

export function autoRenderHtml(opts: NotifyOptions): string {
  const title = opts.title ?? "Notificación";

  const contextBlock = opts.context
    ? renderKV("Contexto", opts.context, opts.truncate ?? 120)
    : "";

  let dataBlock = "";
  if (Array.isArray(opts.data)) {
    dataBlock = renderTable({
      title: "Datos",
      rows: opts.data as Record<string, unknown>[],
      maxRows: opts.maxRows ?? 20,
      truncate: opts.truncate ?? 120,
    });
  } else if (opts.data !== undefined) {
    dataBlock = renderJSON("Datos", opts.data);
  }

  return `
    <h2>${escapeHtml(title)}</h2>
    ${contextBlock}
    ${dataBlock}
  `;
}
