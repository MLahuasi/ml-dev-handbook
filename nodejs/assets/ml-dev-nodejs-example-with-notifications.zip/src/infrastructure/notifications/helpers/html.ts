/** Escapa caracteres peligrosos para HTML */
export function escapeHtml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function trunc(s: unknown, max = 120): string {
  const str = String(s ?? "");
  return str.length > max ? str.slice(0, max) + "…" : str;
}

/** Renderiza pares clave/valor en una tabla simple */
export function renderKV(
  title: string,
  payload?: Record<string, unknown>,
  truncate = 120
): string {
  if (!payload || typeof payload !== "object") return "";
  const rows = Object.entries(payload)
    .map(
      ([k, v]) =>
        `<tr><td><b>${escapeHtml(k)}</b></td><td>${escapeHtml(
          trunc(v, truncate)
        )}</td></tr>`
    )
    .join("");

  return `
    <section style="margin-top:12px">
      <h3>${escapeHtml(title)}</h3>
      <table border="1" cellspacing="0" cellpadding="6">${rows}</table>
    </section>
  `;
}

/** Renderiza un array de objetos como tabla (con límite de filas opcional) */
export function renderTable(opts: {
  title?: string;
  subtitle?: string;
  rows?: Record<string, unknown>[];
  maxRows?: number; // default 20
  truncate?: number; // default 120
}): string {
  const { title, subtitle, rows = [], maxRows = 20, truncate = 120 } = opts;
  if (!rows.length) {
    return `
      <section style="margin-top:12px">
        ${title ? `<h3>${escapeHtml(title)}</h3>` : ""}
        ${subtitle ? `<p>${escapeHtml(subtitle)}</p>` : ""}
        <p><i>Sin filas</i></p>
      </section>
    `;
  }

  const headers = Object.keys(rows[0]);
  const headerRow = headers.map((h) => `<th>${escapeHtml(h)}</th>`).join("");
  const bodyRows = rows
    .slice(0, maxRows)
    .map((r) => {
      const cols = headers
        .map((h) => `<td>${escapeHtml(trunc((r as any)[h], truncate))}</td>`)
        .join("");
      return `<tr>${cols}</tr>`;
    })
    .join("");

  const foot =
    rows.length > maxRows
      ? `<p><i>Mostrando ${maxRows} de ${rows.length} filas</i></p>`
      : "";

  return `
    <section style="margin-top:12px">
      ${title ? `<h3>${escapeHtml(title)}</h3>` : ""}
      ${subtitle ? `<p>${escapeHtml(subtitle)}</p>` : ""}
      <table border="1" cellspacing="0" cellpadding="6">
        <thead><tr>${headerRow}</tr></thead>
        <tbody>${bodyRows}</tbody>
      </table>
      ${foot}
    </section>
  `;
}

/** Renderiza JSON en <pre> escapado */
export function renderJSON(title: string, data: unknown): string {
  const body = escapeHtml(JSON.stringify(data, null, 2));
  return `
    <section style="margin-top:12px">
      <h3>${escapeHtml(title)}</h3>
      <pre>${body}</pre>
    </section>
  `;
}
