export type NotifyAttachment = {
  filename: string;
  path?: string; // archivo local
  content?: string | Buffer; // contenido en memoria
  contentType?: string;
};

/** Nombre de archivo con timestamp seguro para FS/clients */
export function withIsoTimestamp(basename: string, ext: string): string {
  const ts = new Date().toISOString().replace(/[:.]/g, "-");
  return `${basename}_${ts}.${ext.replace(/^\./, "")}`;
}

/** Normaliza contenido a Buffer para evitar issues de encoding */
export function toBufferContent(content: string | Buffer): Buffer {
  return Buffer.isBuffer(content) ? content : Buffer.from(content, "utf-8");
}
