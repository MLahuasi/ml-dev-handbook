// src/infrastructure/notifications/error-notifier.ts

import { mailerReady } from "@jmlq/mailer";
import { envs } from "../../config/plugins/envs.plugin";
import { LogLevel } from "@jmlq/logger";
import { mapMailerEnv } from "../../config/mappers";
import { levelErrorRank, toErrorLogLevel } from "./helpers";

export type ErrorContext = {
  requestId?: string;
  route?: string;
  method?: string;
  ip?: string;
  userAgent?: string;
  extra?: Record<string, unknown>;
};

export async function notifyCriticalError(
  level: LogLevel,
  title: string,
  error: unknown,
  ctx: ErrorContext = {}
) {
  // Flags opcionales de alertas
  const alertsEnabled = Boolean(envs.mailer.MAILER_ALERTS_ENABLED);
  if (!alertsEnabled) return;

  const minLevel = toErrorLogLevel(
    String(envs.mailer.MAILER_ALERTS_MIN_LEVEL ?? "ERROR")
  );
  // Se envía si el nivel es >= MAILER_ALERTS_MIN_LEVEL
  if (levelErrorRank(level) < levelErrorRank(minLevel)) return;

  // Lista de destinatarios desde ENV (coma-separado)
  const toList = String(envs.mailer.MAILER_FROM ?? "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);

  if (!toList.length) return;

  const message = (error as any)?.message ?? String(error);
  const stack = (error as any)?.stack;
  const subject = `[${envs.NODE_ENV ?? "dev"}] ${title}`;

  const html = `
    <h2>${title}</h2>
    <ul>
      <li><b>Nivel:</b> ${LogLevel[level]}</li>
      <li><b>Entorno:</b> ${process.env.NODE_ENV ?? "dev"}</li>
      ${ctx.requestId ? `<li><b>RequestId:</b> ${ctx.requestId}</li>` : ""}
      ${ctx.method ? `<li><b>Método:</b> ${ctx.method}</li>` : ""}
      ${ctx.route ? `<li><b>Ruta:</b> ${ctx.route}</li>` : ""}
      ${ctx.ip ? `<li><b>IP:</b> ${ctx.ip}</li>` : ""}
      ${ctx.userAgent ? `<li><b>UA:</b> ${ctx.userAgent}</li>` : ""}
    </ul>
    <h3>Mensaje</h3>
    <pre>${String(message)}</pre>
    ${
      stack
        ? `<h3>Stack</h3><pre style="white-space:pre-wrap">${String(stack)
            .slice(0, 10000)
            .replace(/</g, "&lt;")}</pre>`
        : ""
    }
    ${
      ctx.extra
        ? `<h3>Contexto</h3><pre style="white-space:pre-wrap">${JSON.stringify(
            ctx.extra
          ).slice(0, 10000)}</pre>`
        : ""
    }
  `;

  try {
    const mailer = await mailerReady(mapMailerEnv());
    await mailer.sendEmail({
      to: toList.map((email) => ({ email })),
      subject,
      htmlBody: html,
    });
  } catch (sendErr) {
    // no romper el flujo de la app por el notifier
    console.error("[notifyCriticalError] send failed:", sendErr);
  }
}
