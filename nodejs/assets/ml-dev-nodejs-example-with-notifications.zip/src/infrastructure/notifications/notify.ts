// src/infrastructure/notifications/notify.ts

import { envs } from "../../config/plugins/envs.plugin";
import { mapMailerEnv } from "../../config/mappers";
import {
  toRecipients,
  escapeHtml,
  renderKV,
  renderTable,
  renderJSON,
  toBufferContent,
  NotifyOptions,
  autoRenderHtml,
} from "./helpers";
import { mailerReady } from "@jmlq/mailer";

// ---------- API principal ----------------------------------------------------

export async function notify(opts: NotifyOptions): Promise<void> {
  const recipients = toRecipients(opts.to);
  if (!recipients.length) return; // sin destinatarios, no envía

  const subject = `[${envs.NODE_ENV ?? "dev"}] ${opts.subject}`;
  const html = opts.html ?? autoRenderHtml(opts);

  const attachments = opts.attachments?.map((a) =>
    a.path
      ? { filename: a.filename, path: a.path, contentType: a.contentType }
      : {
          filename: a.filename,
          content: a.content ? toBufferContent(a.content) : undefined,
          contentType: a.contentType,
        }
  );

  // Mapeo directo de tus MAILER_* a IMailerEnv que espera @jmlq/mailer
  const mailer = await mailerReady(mapMailerEnv());

  await mailer.sendEmail({
    to: recipients, // MailAddress[]
    subject,
    htmlBody: html,
    textBody: opts.text,
    cc: opts.cc ? toRecipients(opts.cc) : undefined,
    bcc: opts.bcc ? toRecipients(opts.bcc) : undefined,
    attachments,
  });
}

/** Helpers exportados por si quieres usarlos fuera */
export const NotifyRender = {
  escapeHtml,
  renderKV,
  renderTable,
  renderJSON,
};
