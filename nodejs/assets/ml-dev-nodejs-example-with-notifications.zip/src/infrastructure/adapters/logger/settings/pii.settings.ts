//Se definine reglas de redacción PII (buscar-y-reemplazar con regex) que el logger aplica antes de persistir/emitir un log.

export type PiiReplacement = {
  pattern: string;
  replaceWith: string;
  flags?: string;
};

export interface PiiConfig {
  enabled: boolean;
  whitelistKeys?: string[];
  blacklistKeys?: string[];
  patterns?: PiiReplacement[];
  deep?: boolean;
  includeDefaults?: boolean;
}

// patrones “de fábrica” (del sistema):
export const DEFAULT_PII_PATTERNS: PiiReplacement[] = [
  //   {
  //     pattern: String.raw`[^@\n\r ]+@[^@\n\r ]+`,
  //     replaceWith: "[EMAIL]",
  //     flags: "g",
  //   },
];

// patrones “del cliente/proyecto”:
export const clientPiiPatterns: PiiReplacement[] = [
  { pattern: String.raw`\b\d{10}\b`, flags: "g", replaceWith: "[EC_DNI]" },
];

// lista negra de nombres de clave que se siempre se ocultan
export const redactKeys: string[] = ["password", "secret"];
// lista blanca de nombres de clave que no se deben ocultar por clave
export const preserveKeys: string[] = ["city"];

// Helpers
// 1. Filtra valores no válidos: elimina null, undefined y "" (cadena vacía).
// 2. Elimina duplicados usando Set.
// 3. Conserva el primero de cada valor repetido (porque Set guarda la primera aparición).
export function dedupeStrings(arr: Array<string | undefined | null>): string[] {
  return [...new Set(arr.filter((x): x is string => !!x && x.length > 0))];
}

// 1. Construye una clave de identidad por patrón: pattern + "__" + replaceWith + "__" + (flags || "").
// 2. Inserta cada elemento en un `Map` usando esa clave. Si la clave ya existe, sobrescribe el anterior (es decir, gana el último).
// 3. Devuelve los valores únicos del `Map`.
export function dedupePatterns(arr: PiiReplacement[]): PiiReplacement[] {
  const m = new Map<string, PiiReplacement>();
  for (const p of arr)
    m.set(`${p.pattern}__${p.replaceWith}__${p.flags ?? ""}`, p);
  return [...m.values()];
}

// Builder unificado
export function buildPiiConfig(
  opts?: PiiConfig
): Required<Omit<PiiConfig, "includeDefaults">> {
  const includeDefaults = opts?.includeDefaults ?? true;

  const patterns = dedupePatterns([
    ...(includeDefaults ? DEFAULT_PII_PATTERNS : []),
    ...clientPiiPatterns,
    ...(opts?.patterns ?? []),
  ]);

  const whitelistKeys = dedupeStrings([
    ...(opts?.whitelistKeys ?? []),
    ...preserveKeys,
  ]);
  const blacklistKeys = dedupeStrings([
    ...(opts?.blacklistKeys ?? []),
    ...redactKeys,
  ]);

  return {
    enabled: !!opts?.enabled,
    whitelistKeys,
    blacklistKeys,
    patterns,
    deep: opts?.deep ?? true,
  };
}
