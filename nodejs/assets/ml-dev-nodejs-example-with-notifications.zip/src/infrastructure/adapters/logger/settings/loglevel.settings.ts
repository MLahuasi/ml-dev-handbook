import { LogLevel } from "@jmlq/logger";

export function toMinLevel(
  level: LogLevel | keyof typeof LogLevel | string
): LogLevel {
  if (typeof level === "number") return level as LogLevel;
  switch (String(level || "debug").toLowerCase()) {
    case "trace":
      return LogLevel.TRACE;
    case "debug":
      return LogLevel.DEBUG;
    case "info":
      return LogLevel.INFO;
    case "warn":
      return LogLevel.WARN;
    case "error":
      return LogLevel.ERROR;
    case "fatal":
      return LogLevel.FATAL;
    default:
      return LogLevel.DEBUG;
  }
}
