import { createFsDatasource } from "@jmlq/logger-plugin-fs";
import type { ILogDatasource } from "@jmlq/logger";

export interface IFsProps {
  basePath: string;
  fileNamePattern: string;
  rotationPolicy: { by: "none" | "day" | "size"; maxSizeMB?: number };
}

export class FsAdapter {
  private constructor(private readonly ds: ILogDatasource) {}
  static create(opts: IFsProps): FsAdapter | undefined {
    try {
      const ds = createFsDatasource({
        basePath: opts.basePath,
        mkdir: true,
        fileNamePattern: opts.fileNamePattern,
        rotation: opts.rotationPolicy,
        onRotate: (oldP, newP) =>
          console.log("[fs] rotated:", oldP, "->", newP),
        onError: (e) => console.error("[fs] error:", e),
      });
      console.log("[logger] Conectado a FS para logs");
      return new FsAdapter(ds);
    } catch (e: any) {
      console.warn("[logger] FS deshabilitado:", e?.message ?? e);
    }
  }
  get datasource(): ILogDatasource {
    return this.ds;
  }
}
