// src/infrastructure/adapters/mailer.adapter.ts

import { mailerReady, type MailMessage } from "@jmlq/mailer";
import {
  MailerPort,
  SendEmailOptions,
} from "../../../domain/ports/mailer.port";
import { mapMailerEnv } from "../../../config/mappers";

export class MailerAdapter implements MailerPort {
  private service!: {
    sendEmail: (msg: MailMessage) => Promise<{ messageId: string }>;
  };
  private initialized = false;

  async init(): Promise<void> {
    // envs.mailer ya cumple IMailerEnv (MAIL_DRIVER, MAIL_HOST, etc.)
    this.service = await mailerReady(mapMailerEnv());
    this.initialized = true;
  }

  private ensureInit() {
    if (!this.initialized) {
      throw new Error(
        "MailerAdapter no inicializado. Llama a init() antes de usar."
      );
    }
  }

  async send(options: SendEmailOptions): Promise<{ messageId: string }> {
    this.ensureInit();

    // Normaliza destinatarios al tipo MailAddress (string | {email,name?})
    const to = Array.isArray(options.to) ? options.to : [options.to];
    const toAsMailAddress = to.map((a) =>
      typeof a === "string" ? a : { email: a.email, name: a.name }
    );

    const ccAsMailAddress = options.cc
      ? (Array.isArray(options.cc) ? options.cc : [options.cc]).map((a) =>
          typeof a === "string" ? a : { email: a.email, name: a.name }
        )
      : undefined;

    const bccAsMailAddress = options.bcc
      ? (Array.isArray(options.bcc) ? options.bcc : [options.bcc]).map((a) =>
          typeof a === "string" ? a : { email: a.email, name: a.name }
        )
      : undefined;

    const attachments = options.attachments?.map((a) =>
      a.path
        ? { filename: a.filename, path: a.path, contentType: a.contentType }
        : {
            filename: a.filename,
            content: a.content,
            contentType: a.contentType,
          }
    );

    const res = await this.service.sendEmail({
      subject: options.subject,
      htmlBody: options.html,
      textBody: options.text,
      to: toAsMailAddress,
      cc: ccAsMailAddress,
      bcc: bccAsMailAddress,
      attachments,
    });

    return { messageId: res.messageId ?? "unknown" };
  }
}
