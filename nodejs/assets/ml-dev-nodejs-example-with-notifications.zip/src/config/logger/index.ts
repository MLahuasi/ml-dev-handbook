
import { LoggerBootstrap } from "../../infrastructure/adapters/logger";
import { envs } from "../plugins/envs.plugin";

declare global {
  var __LOGGER_BOOT__: Promise<LoggerBootstrap> | undefined;
}

async function init() {
  return LoggerBootstrap.create({
    minLevel: envs.logger.LOGGER_LEVEL ?? "debug",
    pii: {
      enabled: envs.logger.LOGGER_PII_ENABLED,
      includeDefaults: envs.logger.LOGGER_PII_INCLUDE_DEFAULTS,
      deep: true,
    },
    adapters: {
      // NOTA: Opcionales depende de las necesidades del cliente
      fs: envs.logger.LOGGER_FS_PATH
        ? {
            basePath: envs.logger.LOGGER_FS_PATH,
            fileNamePattern: "app-{yyyy}{MM}{dd}.log",
            rotationPolicy: { by: "day" },
          }
        : undefined,
      // ---
    },
  });
}

// 1. Es una promesa singleton de LoggerBootstrap
// 2. usa el operador nullish-coalescing (??) para: Reusar globalThis.__LOGGER_BOOT__ si ya existe. En caso contrario crea y memoriza (= init()) la promesa si no existe aún.
// 3. Garantiza una sola inicialización global del sistema de logging (adapters, datasources, PII, etc.) aunque el módulo se importe múltiples veces
export const bootReady: Promise<LoggerBootstrap> =
  globalThis.__LOGGER_BOOT__ ?? (globalThis.__LOGGER_BOOT__ = init());

// 1. Es una promesa que resuelve directamente al logger
// 2. Hace un map de la promesa anterior: bootReady.then(b => b.logger).
export const loggerReady = bootReady.then((b) => b.logger);

// 1. Espera a bootReady y llama boot.flush(), que a su vez pide al logger/datasources que vacíen buffers pendientes (útil antes de apagar el proceso o en tests).
export async function flushLogs() {
  const boot = await bootReady;
  await boot.flush();
}

// 1. Espera a bootReady y llama boot.dispose(), que cierra recursos (conexiones a Mongo/Postgres, file handles, etc.)
export async function disposeLogs() {
  const boot = await bootReady;
  await boot.dispose();
}
