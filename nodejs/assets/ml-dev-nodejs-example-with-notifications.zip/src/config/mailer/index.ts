// src/config/mailer/index.ts

import { MailerAdapter } from "../../infrastructure/adapters/mailer";

let _mailer: MailerAdapter | null = null;

export function getMailer() {
  if (!_mailer) {
    throw new Error(
      "Mailer no inicializado. Llama a mailerReady() en el arranque."
    );
  }
  return _mailer;
}

export async function mailerReady() {
  if (_mailer) return _mailer;
  _mailer = new MailerAdapter();
  await _mailer.init();
  console.log("[mailer] Start");
  return _mailer;
}

/** Azúcar sintáctico para usar desde cualquier lugar */
export const mail = () => getMailer();
