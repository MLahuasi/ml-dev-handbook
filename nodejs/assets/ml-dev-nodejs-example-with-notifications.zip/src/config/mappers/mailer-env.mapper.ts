import { IMailerEnv } from "@jmlq/mailer"; // o tu tipo local
import { envs } from "../plugins/envs.plugin";

export function mapMailerEnv(): IMailerEnv {
  return {
    MAIL_DRIVER:
      envs.mailer.MAIL_DRIVER === "nodemailer" ? "nodemailer" : undefined,
    MAIL_FROM: envs.mailer.MAILER_FROM,
    MAIL_HOST: envs.mailer.MAIL_HOST,
    MAIL_PORT: envs.mailer.MAIL_PORT,
    MAIL_SECURE: envs.mailer.MAIL_SECURE,
    MAIL_USER: envs.mailer.MAILER_EMAIL,
    MAIL_PASS: envs.mailer.MAILER_SECRET_KEY,
  };
}
