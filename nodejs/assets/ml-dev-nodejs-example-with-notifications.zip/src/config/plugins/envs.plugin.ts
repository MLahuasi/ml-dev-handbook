// src/config/plugins/envs.plugin.ts
import "dotenv/config";
import env from "env-var"; // <- default import

export const envs = {
  HOST: env.get("HOST").default("127.0.0.1").asString(),
  PORT: env.get("PORT").default("3000").asPortNumber(),
  NODE_ENV: env.get("NODE_ENV").default("development").asString(),
  logger: {
    LOGGER_LEVEL: env.get("LOGGER_LEVEL").default("debug").asString(),
    LOGGER_PII_ENABLED: env.get("LOGGER_PII_ENABLED").default("false").asBool(),
    LOGGER_PII_INCLUDE_DEFAULTS: env
      .get("LOGGER_PII_INCLUDE_DEFAULTS")
      .default("false")
      .asBool(),
    LOGGER_FS_PATH: env.get("LOGGER_FS_PATH").default("./logs").asString(),
  },
  mailer: {
    MAIL_DRIVER: resolveDriver(
      env.get("MAIL_DRIVER").default("nodemailer").asString()
    ),
    MAILER_FROM: env.get("MAILER_FROM").asString(),
    MAIL_HOST: env
      .get("MAIL_HOST")
      .default(
        resolveHost(env.get("MAILER_SERVICE").default("gmail").asString())
      )
      .asString(),
    MAIL_PORT: env.get("MAIL_PORT").default("587").asIntPositive(),
    MAIL_SECURE: env.get("MAIL_SECURE").default("false").asBool(),

    MAILER_EMAIL: env.get("MAILER_EMAIL").required().asString(),
    MAILER_SECRET_KEY: env.get("MAILER_SECRET_KEY").required().asString(),
    MAILER_ALERTS_ENABLED: env
      .get("MAILER_ALERTS_ENABLED")
      .default("true")
      .asBool(),
    MAILER_ALERTS_MIN_LEVEL: env
      .get("MAILER_ALERTS_MIN_LEVEL")
      .default("ERROR")
      .asString(), // INFO|WARN|ERROR
  },
};

// Mapea el servicio a un host SMTP conocido
function resolveHost(service: string): string {
  switch (service.toLowerCase()) {
    case "gmail":
      return "smtp.gmail.com";
    case "outlook":
      return "smtp.office365.com";
    case "yahoo":
      return "smtp.mail.yahoo.com";
    default:
      return service; // permite custom host
  }
}

function resolveDriver(service: string): string {
  switch (service.toLowerCase()) {
    case "nodemailer":
      return "nodemailer";
    default:
      return service; // permite custom mailer
  }
}
