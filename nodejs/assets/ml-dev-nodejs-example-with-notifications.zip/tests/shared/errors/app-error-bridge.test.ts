// tests/shared/errors/app-error-bridge.test.ts

import { LogLevel } from "@jmlq/logger";
import { getLogLevelForAppError } from "../../../src/shared/errors";

describe("getLogLevelForAppError", () => {
  it("VALIDATION -> WARN", () => {
    expect(getLogLevelForAppError("VALIDATION")).toBe(LogLevel.WARN);
  });
  it("NOT_FOUND -> INFO", () => {
    expect(getLogLevelForAppError("NOT_FOUND")).toBe(LogLevel.INFO);
  });
  it("CONFLICT -> WARN", () => {
    expect(getLogLevelForAppError("CONFLICT")).toBe(LogLevel.WARN);
  });
  it("INTERNAL -> ERROR", () => {
    expect(getLogLevelForAppError("INTERNAL")).toBe(LogLevel.ERROR);
  });
  it("INVARIANT -> ERROR", () => {
    expect(getLogLevelForAppError("INVARIANT")).toBe(LogLevel.ERROR);
  });
});
