jest.mock("../../../src/config/logger", () => {
  const calls: Array<{ level: string; payload: any }> = [];
  const fakeLogger = {
    info: (evt: string, payload: any) => calls.push({ level: "info", payload }),
    warn: (evt: string, payload: any) => calls.push({ level: "warn", payload }),
    error: (evt: string, payload: any) =>
      calls.push({ level: "error", payload }),
    __calls: calls,
  };
  return { loggerReady: Promise.resolve(fakeLogger), __fakeLogger: fakeLogger };
});

import "../../../src/shared/errors/app-error-logger-bridge";
import { AppError } from "../../../src/shared/errors/app-error";

// Obtén __fakeLogger desde el mock en runtime (evita el error de tipos)
const { __fakeLogger } = jest.requireMock("../../../src/config/logger") as {
  __fakeLogger: { __calls: Array<{ level: string; payload: any }> };
};

describe("AppError hook -> logger bridge", () => {
  it("VALIDATION dispara warn", async () => {
    AppError.validation("bad input");
    // Deja tick al event loop para que el bridge se inicialice si hace falta
    await new Promise((r) => setTimeout(r, 0));
    expect(__fakeLogger.__calls.at(-1)?.level).toBe("warn");
  });

  it("NOT_FOUND dispara info", async () => {
    AppError.notFound("x");
    await new Promise((r) => setTimeout(r, 0));
    expect(__fakeLogger.__calls.at(-1)?.level).toBe("info");
  });

  it("INTERNAL dispara error", async () => {
    AppError.internal("fatal");
    await new Promise((r) => setTimeout(r, 0));
    expect(__fakeLogger.__calls.at(-1)?.level).toBe("error");
  });
});
