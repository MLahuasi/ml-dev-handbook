// tests/presentation/http/error.middleware.test.ts

import { getHttpStatusForAppError } from "../../../src/presentation/middlewares/http/error.middleware";

describe("getHttpStatusForAppError", () => {
  it("VALIDATION -> 400", () => {
    expect(getHttpStatusForAppError("VALIDATION")).toBe(400);
  });
  it("NOT_FOUND -> 404", () => {
    expect(getHttpStatusForAppError("NOT_FOUND")).toBe(404);
  });
  it("CONFLICT -> 409", () => {
    expect(getHttpStatusForAppError("CONFLICT")).toBe(409);
  });
  it("INVARIANT -> 422", () => {
    expect(getHttpStatusForAppError("INVARIANT")).toBe(422);
  });
  it("INTERNAL -> 500", () => {
    expect(getHttpStatusForAppError("INTERNAL")).toBe(500);
  });
});
