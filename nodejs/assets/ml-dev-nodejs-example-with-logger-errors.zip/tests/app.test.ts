import request from "supertest";
import { createServer } from "../src/presentation/server";
import { loggerReady } from "../src/config/logger";

describe("App (e2e)", () => {
  let app: ReturnType<typeof createServer>;

  beforeAll(async () => {
    const logger = await loggerReady;
    app = createServer(logger);
  });

  it("GET /health → 200", async () => {
    const res = await request(app).get("/health");
    expect(res.status).toBe(200);
    expect(res.body).toEqual({ ok: true });
  });

  // Puedes añadir más tests para otras rutas:
  // it("POST /users → 201", async () => { ... });
});
