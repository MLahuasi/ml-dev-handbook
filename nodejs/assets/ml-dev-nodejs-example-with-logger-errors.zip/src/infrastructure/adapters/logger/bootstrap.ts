import {
  createLogger,
  CompositeDatasource,
  type ILogDatasource,
} from "@jmlq/logger";
import { buildPiiConfig } from "./settings/pii.settings";
import { toMinLevel } from "./settings/loglevel.settings";
// NOTA: Opcionales depende de las necesidades del cliente
import { FsAdapter, type IFsProps } from "./adapters/fs.adapter";

export interface LoggerBootstrapOptions {
  minLevel: string | number;
  pii?: {
    enabled?: boolean;
    whitelistKeys?: string[];
    blacklistKeys?: string[];
    patterns?: any[];
    deep?: boolean;
    includeDefaults?: boolean;
  };
  adapters?: {
    // NOTA: Opcionales depende de las necesidades del cliente
    fs?: IFsProps;
  };
}

export class LoggerBootstrap {
  private constructor(
    private readonly _logger: ReturnType<typeof createLogger>,
    private readonly _ds: ILogDatasource
  ) {}

  static async create(opts: LoggerBootstrapOptions): Promise<LoggerBootstrap> {
    const dsList: ILogDatasource[] = [];

    // NOTA: Opcionales depende de las necesidades del cliente
    if (opts.adapters?.fs) {
      const fs = FsAdapter.create(opts.adapters.fs);
      if (fs) dsList.push(fs.datasource);
    }
    //----

    if (dsList.length === 0)
      throw new Error("[logger] No hay datasources válidos.");
    const datasource =
      dsList.length === 1 ? dsList[0] : new CompositeDatasource(dsList);

    const pii = buildPiiConfig({
      enabled: opts.pii?.enabled ?? false,
      includeDefaults: opts.pii?.includeDefaults ?? true,
      whitelistKeys: opts.pii?.whitelistKeys,
      blacklistKeys: opts.pii?.blacklistKeys,
      patterns: opts.pii?.patterns,
      deep: opts.pii?.deep ?? true,
    });

    const logger = createLogger(datasource, {
      minLevel: toMinLevel(opts.minLevel),
      pii,
    });
    return new LoggerBootstrap(logger, datasource);
  }

  get logger() {
    return this._logger;
  }
  async flush() {
    const any = this._logger as any;
    if (typeof any.flush === "function") await any.flush();
  }
  async dispose() {
    const any = this._logger as any;
    if (typeof any.dispose === "function") await any.dispose();
  }
}
