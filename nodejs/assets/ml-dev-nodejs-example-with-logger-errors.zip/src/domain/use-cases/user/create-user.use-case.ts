// src/domain/use-cases/user/create-user.use-case.ts

import { ILogger } from "@jmlq/logger";
import { AppError } from "../../../shared/errors";
import { CreateUserDto } from "../../dtos";
import { UserEntity } from "../../entities";
import { UserRepository } from "../../repositories";

export class CreateUserUseCase {
  constructor(
    private readonly userRepo: UserRepository,
    private readonly logger?: ILogger
  ) {}

  async execute(dto: CreateUserDto): Promise<UserEntity> {
    // Aquí puedes aplicar lógica de negocio (ej: validar duplicados)

    // IMPORTANTE: Así se lanzan errores desde el Use-Case
    this.logger?.info("createUser.validate", { email: dto.email });

    if (!dto.email) {
      this.logger?.warn("createUser.invalid", { dto });
      throw AppError.validation("Email inválido");
    }

    return this.userRepo.createUser(dto);
  }
}
