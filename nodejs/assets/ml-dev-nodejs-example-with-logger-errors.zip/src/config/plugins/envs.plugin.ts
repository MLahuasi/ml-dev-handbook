// src/config/plugins/envs.plugin.ts
import "dotenv/config";
import env from "env-var"; // <- default import

export const envs = {
  HOST: env.get("HOST").default("127.0.0.1").asString(),
  PORT: env.get("PORT").default("3000").asPortNumber(),
  NODE_ENV: env.get("NODE_ENV").default("development").asString(),
  logger: {
    LOGGER_LEVEL: env.get("LOGGER_LEVEL").default("debug").asString(),
    LOGGER_PII_ENABLED: env.get("LOGGER_PII_ENABLED").default("false").asBool(),
    LOGGER_PII_INCLUDE_DEFAULTS: env
      .get("LOGGER_PII_INCLUDE_DEFAULTS")
      .default("false")
      .asBool(),
    LOGGER_FS_PATH: env.get("LOGGER_FS_PATH").default("./logs").asString(),
  },
};
