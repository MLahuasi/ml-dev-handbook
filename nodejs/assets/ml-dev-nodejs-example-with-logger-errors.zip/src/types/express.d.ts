import "express";
import type { ILogger } from "@jmlq/logger";

// Eso significa que cada req trae un logger y un requestId.
declare module "express-serve-static-core" {
  interface Request {
    logger?: ILogger;
    requestId?: string;
  }
}
