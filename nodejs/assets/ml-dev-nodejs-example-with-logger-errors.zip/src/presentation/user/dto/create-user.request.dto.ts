// src/presentation/user/dto/create-user.request.dto.ts
export interface CreateUserRequestDto {
  name: string;
  email: string;
}
