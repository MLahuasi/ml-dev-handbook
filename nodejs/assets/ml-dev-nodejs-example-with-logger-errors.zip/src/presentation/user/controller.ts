// src/presentation/user/controller.ts
import type { NextFunction, Request, Response } from "express";
import { UserRepository } from "../../domain/repositories";
import { CreateUserUseCase } from "../../domain/use-cases/user";

export class UserController {
  constructor(private readonly userRepo: UserRepository) {}

  create = async (req: Request, res: Response, next: NextFunction) => {
    try {
      // Usa el logger con contexto
      req.logger?.info("user.create.start", {
        requestId: req.requestId,
        body: req.body,
      });
      const useCase = new CreateUserUseCase(this.userRepo);
      const user = await useCase.execute(req.body);

      req.logger?.info("user.create.success", {
        requestId: req.requestId,
        userId: user.id,
      });
      res.status(201).json(user);
    } catch (err: any) {
      return next(err);
    }
  };

  list = async (req: Request, res: Response, next: NextFunction) => {
    try {
      req.logger?.info("user.list.start", { requestId: req.requestId });

      const users = await this.userRepo.getUsers();

      req.logger?.info("user.list.success", {
        count: users.length,
        requestId: req.requestId,
      });
      res.json(users);
    } catch (err: any) {
      return next(err);
    }
  };
}
