// src/app.ts
import { envs } from "./config/plugins/envs.plugin";
import { createServer } from "./presentation/server";
import { disposeLogs, flushLogs, loggerReady } from "./config/logger";
// import { AppError } from "./shared/errors";

// Importar el bridge una sola vez inicializa el hook de AppError
import "./shared/errors/app-error-logger-bridge";

// --- Inicializa el hook una sola vez ---
// loggerReady.then((logger) => {
//   // Cada vez que se construya un AppError, se registra acá
//   AppError.hook = (err) => logger.error("AppError", err.toLog());
// });

async function bootstrap() {
  const logger = await loggerReady;
  const app = createServer(logger);
  const server = app.listen(envs.PORT, envs.HOST, () => {
    console.log(`🚀 Server running at http://${envs.HOST}:${envs.PORT}`);
    logger.info("http.start", { host: envs.HOST, port: envs.PORT });
  });

  server.on("error", async (err: any) => {
    logger.error("http.listen.error", {
      message: err?.message,
      stack: err?.stack,
    });
    await flushLogs().catch(() => {});
    await disposeLogs().catch(() => {});
    process.exit(1);
  });

  // 3) Señales de apagado limpio
  const shutdown = async (reason: string, code = 0) => {
    logger.info("app.shutdown.begin", { reason });
    server.close(async () => {
      try {
        await flushLogs();
      } catch {}
      try {
        await disposeLogs();
      } catch {}
      logger.info("app.shutdown.end", { code });
      process.exit(code);
    });
  };

  process.on("SIGINT", () => shutdown("SIGINT"));
  process.on("SIGTERM", () => shutdown("SIGTERM"));

  // Fallos no controlados
  process.on("unhandledRejection", async (err) => {
    const e = err as any;
    logger.error("unhandled.rejection", {
      message: e?.message,
      stack: e?.stack,
    });
    await shutdown("unhandledRejection", 1);
  });

  process.on("uncaughtException", async (err) => {
    logger.error("uncaught.exception", {
      message: err.message,
      stack: err.stack,
    });
    await shutdown("uncaughtException", 1);
  });
}

bootstrap().catch(async (err) => {
  // Falla durante el bootstrap
  const logger = await loggerReady.catch(() => null);
  if (logger) {
    logger.error("bootstrap.fatal", {
      message: (err as Error)?.message,
      stack: (err as Error)?.stack,
    });
    await flushLogs().catch(() => {});
    await disposeLogs().catch(() => {});
  } else {
    // último recurso si el logger no llegó a inicializar
    console.error("Fatal error (no logger):", err);
  }
  process.exit(1);
});
