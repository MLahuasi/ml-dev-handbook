// src/shared/errors/app-error-logger-bridge.ts
import { loggerReady } from "../../config/logger";
import { AppError, AppErrorCode } from "./app-error";
import { LogLevel } from "@jmlq/logger"; // asumiendo enum o tipos del core

/** Mapeo central: AppErrorCode -> LogLevel */
export function getLogLevelForAppError(code: AppErrorCode): LogLevel {
  switch (code) {
    case "VALIDATION":
      return LogLevel.WARN;
    case "NOT_FOUND":
      return LogLevel.INFO;
    case "CONFLICT":
      return LogLevel.WARN;
    case "INTERNAL":
      return LogLevel.ERROR;
    case "INVARIANT":
      return LogLevel.ERROR;
    default:
      return LogLevel.ERROR;
  }
}

/**
 * Inicializa el hook de AppError una sola vez.
 * Nota: side-effect al importarlo (bootstrap implícito).
 */
let initialized = false;

async function init() {
  if (initialized) return;
  initialized = true;

  const logger = await loggerReady; // Reutiliza tu inicialización existente

  AppError.setHook((err) => {
    const lvl = getLogLevelForAppError(err.code);
    const eventName = "app.error"; // evento estructurado
    const payload = err.toLog();

    // Enrutamiento por nivel (usa el método del logger correcto)
    switch (lvl) {
      case LogLevel.INFO:
        logger.info(eventName, payload);
        break;
      case LogLevel.WARN:
        logger.warn(eventName, payload);
        break;
      case LogLevel.ERROR:
      default:
        logger.error(eventName, payload);
        break;
    }
  });
}

// Arranca en cuanto se importa el módulo.
init().catch((e) => {
  // Último recurso si el logger no inicializa (no rompe la app)
  // eslint-disable-next-line no-console
  console.error("[AppErrorBridge] init failed:", e);
});
